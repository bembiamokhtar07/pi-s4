from django.shortcuts import render, redirect
from django.http import Http404
from .data import TOOLS_DATA, PRIMARY_TOOLS, SECONDARY_TOOLS, ALL_TOOLS

def get_lang(request):
    return request.session.get('lang', 'fr')

def set_language(request, lang):
    request.session['lang'] = lang
    return redirect(request.META.get('HTTP_REFERER', '/'))

def home(request):
    return render(request, 'tools/home.html', {
        'primary_tools': PRIMARY_TOOLS,
        'secondary_tools': SECONDARY_TOOLS,
        'lang': get_lang(request), 'page': 'home'
    })

def tool_detail(request, tool_id):
    tool = TOOLS_DATA.get(tool_id)
    if not tool:
        raise Http404
    other_primary = [t for t in PRIMARY_TOOLS if t['id'] != tool_id]
    return render(request, 'tools/detail.html', {
        'tool': tool,
        'other_tools': other_primary[:3],
        'lang': get_lang(request), 'page': 'detail'
    })

def compare(request):
    t1 = TOOLS_DATA.get(request.GET.get('tool1',''))
    t2 = TOOLS_DATA.get(request.GET.get('tool2',''))
    return render(request, 'tools/compare.html', {
        'all_tools': ALL_TOOLS,
        'tool1': t1, 'tool2': t2,
        'lang': get_lang(request), 'page': 'compare'
    })

def statistics(request):
    stats = []
    for t in ALL_TOOLS:
        s = t['stats']
        avg = round((s['satisfaction']+s['ease']+s['interactivity']+s['accessibility'])/4,1)
        stats.append({**t, 'average': avg})
    stats.sort(key=lambda x: x['average'], reverse=True)
    return render(request, 'tools/statistics.html', {
        'stats': stats, 'lang': get_lang(request), 'page': 'statistics'
    })
