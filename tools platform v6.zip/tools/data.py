# ── Logos ────────────────────────────────────────────────────────────
LOGO_MOODLE      = "/static/tools/images/moodle_logo.jpeg"
LOGO_GCLASSROOM  = "/static/tools/images/gclassroom.svg"
LOGO_TEAMS       = "/static/tools/images/teams.svg"
LOGO_GMEET       = "/static/tools/images/gmeet.svg"
LOGO_LOOM        = "/static/tools/images/loom.svg"
LOGO_PADLET      = "/static/tools/images/padlet.svg"
LOGO_WOOCLAP     = "/static/tools/images/wooclap.svg"
LOGO_MOOCS       = "/static/tools/images/moocs.svg"
LOGO_CANVA       = "/static/tools/images/canva.svg"
LOGO_EXAMNET     = "/static/tools/images/exam_net.svg"

# ── PDF paths (only for tools that HAVE a dedicated study) ───────────
PDF_BOLEGUIN   = "/static/tools/pdf/moodle_boleguin_2019.pdf"
PDF_BENABID    = "/static/tools/pdf/moodle_benabid_2017.pdf"
PDF_BEDDAA     = "/static/tools/pdf/outils_numeriques_beddaa_2025.pdf"
PDF_GHARAIBEH  = "/static/tools/pdf/teams_gharaibeh_2023.pdf"

# ── Helper: reference type ───────────────────────────────────────────
# type="pdf"  → show PDF button
# type="url"  → show Visit website button

TOOLS_DATA = {

    # ════════════════════════════════════════════════════════════════
    # PRIMARY TOOLS
    # ════════════════════════════════════════════════════════════════

    "moodle": {
        "id": "moodle", "primary": True,
        "name": "Moodle",
        "logo": LOGO_MOODLE,
        "color": "#C96A0F", "color_light": "#FEF4EA",
        "category": {"fr": "LMS / Préparation des cours", "ar": "نظام إدارة التعلم"},
        "website": "https://moodle.org",
        "summary": {
            "fr": (
                "Moodle (Modular Object-Oriented Dynamic Learning Environment) est la plateforme "
                "d'apprentissage en ligne open source la plus utilisée dans l'enseignement supérieur. "
                "Elle permet aux enseignants de centraliser les ressources pédagogiques, d'organiser "
                "des activités interactives (quiz, devoirs, forums) et de suivre la progression des étudiants. "
                "Boléguin, Guillon et Kennel (2019) ont mené une grande enquête auprès de 347 "
                "enseignants-chercheurs dans trois universités françaises et ont montré que 65 % "
                "d'entre eux utilisent Moodle. L'usage est fortement corrélé à l'enseignement à distance "
                "(probabilité multipliée par 6), à la formation continue et au profil féminin maître de conférences. "
                "Benabid (2017) a suivi l'évolution des usages sur 3 ans en Tunisie : la connexion "
                "quotidienne est passée de 28 % à 70 %, avec un glissement des modes transmissifs vers "
                "les modes interactifs via le forum. Le rapport pédagogique lui attribue 5/5 pour "
                "la centralisation, l'accessibilité 24h/24 et la compatibilité avec l'APC."
            ),
            "ar": (
                "Moodle منصة التعلم الإلكتروني مفتوحة المصدر الأكثر استخداماً في التعليم العالي. "
                "تُمكّن الأساتذة من مركزة الموارد البيداغوجية وتنظيم الأنشطة التفاعلية ومتابعة تقدم الطلاب. "
                "أثبتت دراسة بولغان وغيون وكينيل (2019) على 347 أستاذاً في ثلاث جامعات فرنسية أن 65% "
                "منهم يستخدمون Moodle، مع ارتباط قوي بالتعليم عن بُعد (×6). "
                "تتبّعت بنعبيد (2017) التطور 3 سنوات في تونس: الاتصال اليومي ارتفع من 28% إلى 70%، "
                "وانتقل النمط من التلقين إلى التفاعل. حازت على تقييم 5/5 للمركزة والوصول والتوافق مع مقاربة الكفاءات."
            )
        },
        "advantages": {
            "fr": ["Centralisation de toutes les ressources pédagogiques", "Accessibilité 24h/24 depuis n'importe quel appareil", "Compatible avec l'Approche Par Compétences (APC)", "Quiz, devoirs et grilles de correction intégrés", "Forum de discussion favorisant l'interaction", "Suivi détaillé via les traces numériques", "Logiciel libre, gratuit et open source"],
            "ar": ["مركزة جميع الموارد البيداغوجية", "وصول 24/24 من أي جهاز", "متوافقة مع مقاربة الكفاءات (APC)", "اختبارات وواجبات وشبكات تصحيح مدمجة", "منتديات نقاش لتعزيز التفاعل", "تتبع تفصيلي عبر الآثار الرقمية", "برنامج مجاني ومفتوح المصدر"]
        },
        "disadvantages": {
            "fr": ["Interface complexe nécessitant une formation initiale", "Résistance d'une minorité à la communication asynchrone", "Usage inégal selon la discipline et le contexte", "Nécessite une connexion Internet stable"],
            "ar": ["واجهة معقدة تتطلب تكويناً أولياً", "مقاومة من بعض المتعلمين للتواصل غير المتزامن", "تفاوت الاستخدام حسب التخصص والسياق", "يتطلب اتصالاً ثابتاً بالإنترنت"]
        },
        "stats": {"adoption": 65, "satisfaction": 5, "ease": 3, "interactivity": 4, "accessibility": 4},
        "references": [
            {
                "type": "pdf",
                "authors": "Boléguin V., Guillon S. & Kennel S.", "year": "2019",
                "title": "L'usage de Moodle à l'université : vers une typologie des utilisateurs parmi les enseignants-chercheurs",
                "journal": "Revue internationale des technologies en pédagogie universitaire (RITPU)",
                "vol": "16(3)", "pages": "39-56",
                "doi": "https://doi.org/10.18162/ritpu-2019-v16n3-03",
                "pdf": PDF_BOLEGUIN,
                "link_label": {"fr": "Lire l'article complet (PDF)", "ar": "قراءة المقال كاملاً (PDF)"}
            },
            {
                "type": "pdf",
                "authors": "Benabid F.", "year": "2017",
                "title": "Une plateforme Moodle dans une formation hybride diplômante : étude de l'évolution des usages",
                "journal": "Revue internationale des technologies en pédagogie universitaire (RITPU)",
                "vol": "14(2)", "pages": "24-38",
                "doi": "https://doi.org/10.18162/ritpu-2017-v14n2-02",
                "pdf": PDF_BENABID,
                "link_label": {"fr": "Lire l'article complet (PDF)", "ar": "قراءة المقال كاملاً (PDF)"}
            },
        ]
    },

    "google_classroom": {
        "id": "google_classroom", "primary": True,
        "name": "Google Classroom",
        "logo": LOGO_GCLASSROOM,
        "color": "#1E6B3C", "color_light": "#EBF5EE",
        "category": {"fr": "LMS / Gestion de classe", "ar": "إدارة الفصل الدراسي"},
        "website": "https://classroom.google.com",
        "summary": {
            "fr": (
                "Google Classroom est une plateforme de gestion de classe en ligne gratuite "
                "développée par Google, intégrée à G Suite (Drive, Docs, Meet, Forms). "
                "Elle permet de créer des classes virtuelles, distribuer des devoirs, fournir "
                "du feedback et communiquer en temps réel. "
                "Les plateformes LMS ont démontré, selon Bouaddi et al. (2025), un impact positif "
                "sur la gestion du temps (β=0,45, p<0,01) et la communication (β=0,40, p<0,01). "
                "Google Classroom se distingue par sa simplicité et son intégration avec Google Meet, "
                "Forms et Drive. Contrairement à Moodle, elle est hébergée dans le cloud sans "
                "installation locale, facilitant son déploiement dans les pays en développement."
            ),
            "ar": (
                "Google Classroom منصة إدارة الفصل الدراسي المجانية من Google، مدمجة مع G Suite. "
                "تتيح إنشاء فصول افتراضية وتوزيع الواجبات وتقديم التغذية الراجعة والتواصل الفوري. "
                "أثبتت دراسة بوعدي وآخرين (2025) تأثيرها على إدارة الوقت (β=0.45) والتواصل (β=0.40). "
                "تتميز بسهولة الاستخدام والتكامل مع Google Meet وForms وDrive، "
                "مستضافة سحابياً دون تثبيت محلي."
            )
        },
        "advantages": {
            "fr": ["Entièrement gratuit pour les établissements", "Intégration native avec l'écosystème Google", "Interface très intuitive, prise en main rapide", "Hébergé dans le cloud, sans installation", "Notifications automatiques", "Compatible mobile iOS et Android"],
            "ar": ["مجاني تماماً للمؤسسات", "تكامل مع منظومة Google كاملة", "واجهة بديهية سريعة الإتقان", "مستضافة سحابياً دون تثبيت", "إشعارات تلقائية", "متوافقة مع الهاتف"]
        },
        "disadvantages": {
            "fr": ["Fonctionnalités pédagogiques plus limitées que Moodle", "Dépendance totale à Google", "Peu de personnalisation", "Rubrics d'évaluation limitées"],
            "ar": ["ميزات بيداغوجية أقل من Moodle", "اعتماد كلي على Google", "تخصيص محدود", "شبكات تصحيح محدودة"]
        },
        "stats": {"adoption": 60, "satisfaction": 4, "ease": 5, "interactivity": 3, "accessibility": 5},
        "references": [
            {
                "type": "pdf",
                "authors": "Bouaddi M., Oubayoucef M., El Filali M., Beddaa M. & Khaldi S.", "year": "2025",
                "title": "Impact des outils numériques sur l'acquisition et l'amélioration des compétences transversales",
                "journal": "IRAFEM", "vol": "Vol.1 Issue 1", "pages": "1-24", "doi": "",
                "pdf": PDF_BEDDAA,
                "link_label": {"fr": "Lire l'étude complète (PDF)", "ar": "قراءة الدراسة كاملةً (PDF)"}
            },
            {
                "type": "url",
                "authors": "Google for Education", "year": "2024",
                "title": "Google Classroom — Plateforme officielle",
                "journal": "Google", "vol": "", "pages": "", "doi": "",
                "url": "https://classroom.google.com",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            },
        ]
    },

    "microsoft_teams": {
        "id": "microsoft_teams", "primary": True,
        "name": "Microsoft Teams",
        "logo": LOGO_TEAMS,
        "color": "#3B3FA0", "color_light": "#EEEFFE",
        "category": {"fr": "Communication / Enseignement à distance", "ar": "التواصل / التعليم عن بُعد"},
        "website": "https://www.microsoft.com/microsoft-teams",
        "summary": {
            "fr": (
                "Microsoft Teams est une plateforme de communication et de collaboration devenue "
                "incontournable depuis la pandémie COVID-19. Elle combine visioconférence, messagerie, "
                "partage de fichiers et enregistrement des séances. "
                "Gharaibeh (2023) a mesuré la satisfaction de 520 étudiants jordaniens avec le modèle "
                "UTAUT2 : sept facteurs expliquent 38,1 % de la variance, dont l'espérance de "
                "performance (β=0,257), l'influence sociale (β=0,218), la flexibilité (β=0,204) "
                "et la confiance étudiante (β=0,107). La flexibilité est particulièrement valorisée : "
                "Teams permet de suivre les cours depuis n'importe où et d'enregistrer les séances."
            ),
            "ar": (
                "Microsoft Teams منصة تواصل وتعاون متكاملة أساسية منذ كوفيد-19، تجمع مؤتمرات الفيديو "
                "والمراسلة ومشاركة الملفات وتسجيل الجلسات. "
                "قاس غرايبة (2023) رضا 520 طالباً أردنياً بنموذج UTAUT2: 7 عوامل تفسر 38.1% من "
                "تباين الرضا — توقع الأداء (β=0.257) والتأثير الاجتماعي (β=0.218) "
                "والمرونة (β=0.204). المرونة ميزة جوهرية تتيح متابعة الدروس وتسجيلها."
            )
        },
        "advantages": {
            "fr": ["Flexibilité : cours depuis n'importe où", "Enregistrement automatique des séances", "Intégration complète Microsoft 365", "Chat, vidéo et partage dans une seule app", "Encourage la participation des timides", "Satisfaction validée par étude UTAUT2"],
            "ar": ["مرونة كاملة: دروس من أي مكان", "تسجيل تلقائي للجلسات", "تكامل مع Microsoft 365", "دردشة وفيديو ومشاركة في تطبيق واحد", "يشجع الطلاب الخجولين", "رضا مثبت بدراسة UTAUT2"]
        },
        "disadvantages": {
            "fr": ["Coût d'abonnement sans licence Microsoft", "Internet instable = obstacle majeur", "Courbe d'apprentissage pour les enseignants", "Dépendance à l'infrastructure Microsoft"],
            "ar": ["تكلفة الاشتراك بدون رخصة Microsoft", "إنترنت غير مستقر عائق كبير", "منحنى تعلم للأساتذة", "اعتماد على Microsoft"]
        },
        "stats": {"adoption": 70, "satisfaction": 4, "ease": 4, "interactivity": 4, "accessibility": 5},
        "references": [
            {
                "type": "pdf",
                "authors": "Gharaibeh M.K.", "year": "2023",
                "title": "Measuring student satisfaction of Microsoft Teams as an online learning platform in Jordan: An application of UTAUT2 model",
                "journal": "Human Systems Management", "vol": "42", "pages": "121-130",
                "doi": "https://doi.org/10.3233/HSM-220032",
                "pdf": PDF_GHARAIBEH,
                "link_label": {"fr": "Lire l'étude complète (PDF)", "ar": "قراءة الدراسة كاملةً (PDF)"}
            },
        ]
    },

    "google_meet": {
        "id": "google_meet", "primary": True,
        "name": "Google Meet",
        "logo": LOGO_GMEET,
        "color": "#0D6E4A", "color_light": "#E8F5EE",
        "category": {"fr": "Visioconférence / Cours en direct", "ar": "مؤتمرات الفيديو / الدروس المباشرة"},
        "website": "https://meet.google.com",
        "summary": {
            "fr": (
                "Google Meet est l'outil de visioconférence de Google, intégré à Google Workspace "
                "et Google Classroom. Il permet des cours en direct, tutoriels et réunions pédagogiques "
                "avec jusqu'à 100 participants en version gratuite. "
                "Gharaibeh (2023) montre que la flexibilité (β=0,204) et la facilité d'accès sont des "
                "facteurs clés de satisfaction. Google Meet excelle grâce à une interface minimaliste "
                "et un accès direct via navigateur sans téléchargement. "
                "Bouaddi et al. (2025) confirment que les outils de communication en ligne améliorent "
                "les compétences en communication (β=0,40, p<0,01)."
            ),
            "ar": (
                "Google Meet أداة الفيديو كونفرانس من Google، مدمجة مع Workspace وClassroom. "
                "تُنظَّم بها دروس مباشرة ولقاءات بيداغوجية حتى 100 مشارك مجاناً. "
                "تُظهر دراسة غرايبة (2023) أن المرونة (β=0.204) وسهولة الوصول عوامل رضا جوهرية. "
                "يتميز بواجهة مبسطة ووصول مباشر عبر المتصفح دون تنزيل."
            )
        },
        "advantages": {
            "fr": ["Accès direct via navigateur, aucun téléchargement", "Intégration avec Google Classroom et Calendar", "Gratuit jusqu'à 100 participants", "Sous-titres automatiques en temps réel", "Qualité vidéo et audio excellente", "Compatible tous appareils"],
            "ar": ["وصول مباشر عبر المتصفح دون تنزيل", "تكامل مع Google Classroom وCalendar", "مجاني حتى 100 مشارك", "ترجمة تلقائية فورية", "جودة فيديو وصوت ممتازة", "متوافق مع جميع الأجهزة"]
        },
        "disadvantages": {
            "fr": ["Moins de fonctionnalités que Teams", "Pas d'enregistrement automatique (version gratuite)", "Dépendance à Internet stable", "Pas de quiz intégré"],
            "ar": ["ميزات تعاون أقل من Teams", "لا تسجيل تلقائي في النسخة المجانية", "اعتماد على إنترنت مستقر", "لا اختبارات مدمجة"]
        },
        "stats": {"adoption": 58, "satisfaction": 4, "ease": 5, "interactivity": 3, "accessibility": 5},
        "references": [
            {
                "type": "pdf",
                "authors": "Gharaibeh M.K.", "year": "2023",
                "title": "Measuring student satisfaction of Microsoft Teams as an online learning platform in Jordan",
                "journal": "Human Systems Management", "vol": "42", "pages": "121-130",
                "doi": "https://doi.org/10.3233/HSM-220032",
                "pdf": PDF_GHARAIBEH,
                "link_label": {"fr": "Lire l'étude (PDF)", "ar": "قراءة الدراسة (PDF)"}
            },
            {
                "type": "url",
                "authors": "Google", "year": "2024",
                "title": "Google Meet — Plateforme officielle de visioconférence",
                "journal": "Google", "vol": "", "pages": "", "doi": "",
                "url": "https://meet.google.com",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            },
        ]
    },

    "loom": {
        "id": "loom", "primary": True,
        "name": "Loom",
        "logo": LOGO_LOOM,
        "color": "#4540B0", "color_light": "#EDEEFF",
        "category": {"fr": "Feedback vidéo / Enregistrement d'écran", "ar": "تغذية راجعة مرئية / تسجيل الشاشة"},
        "website": "https://www.loom.com",
        "summary": {
            "fr": (
                "Loom est un outil d'enregistrement vidéo d'écran permettant aux enseignants de fournir "
                "un feedback audio-visuel personnalisé. Utilisé pour corriger des devoirs, expliquer des "
                "erreurs, commenter des projets et assurer un accompagnement individuel. "
                "Selon le rapport pédagogique, Loom obtient 5/5 car le feedback vidéo est mieux compris "
                "qu'un commentaire écrit et renforce la relation enseignant-étudiant. "
                "Benabid (2017) montre que les étudiants en dispositif hybride préfèrent les interactions "
                "directes et que les messages textuels ne remplacent pas la présence sociale. Loom répond "
                "à cette limite en ajoutant voix et visage au feedback à distance. "
                "Bouaddi et al. (2025) confirment que les outils de communication numérique améliorent "
                "les compétences en communication (β=0,40, p<0,01)."
            ),
            "ar": (
                "Loom أداة تسجيل فيديو الشاشة للتغذية الراجعة السمعية البصرية المخصصة. "
                "تُستخدم لتصحيح الواجبات وشرح الأخطاء والتعليق على المشاريع والمرافقة الفردية. "
                "نال Loom تقييم 5/5 لأن التغذية المرئية أوضح من التعليق الكتابي وتعزز العلاقة. "
                "تُبيّن بنعبيد (2017) أن الطلاب يفضلون التفاعل المباشر وأن النصوص لا تعوض الحضور. "
                "تؤكد دراسة بوعدي وآخرين (2025) التحسين الدال في مهارات التواصل (β=0.40)."
            )
        },
        "advantages": {
            "fr": ["Feedback vidéo humain et personnalisé", "Mieux compris qu'un commentaire écrit", "Renforce la relation enseignant-étudiant", "Gain de temps lors de corrections complexes", "Les étudiants peuvent revoir le feedback", "Partage simple via lien URL"],
            "ar": ["تغذية راجعة إنسانية مخصصة", "أوضح للطلاب من التعليق المكتوب", "تعزز العلاقة مع الطالب عن بُعد", "توفير الوقت عند التصحيحات", "الطلاب يراجعونها في أي وقت", "مشاركة سهلة عبر رابط"]
        },
        "disadvantages": {
            "fr": ["Nécessite microphone et caméra", "Temps de préparation plus long", "Stockage limité en version gratuite", "Connexion Internet nécessaire"],
            "ar": ["يتطلب ميكروفوناً وكاميرا", "وقت تحضير أطول", "تخزين محدود في النسخة المجانية", "يتطلب اتصالاً بالإنترنت"]
        },
        "stats": {"adoption": 40, "satisfaction": 5, "ease": 4, "interactivity": 3, "accessibility": 4},
        "references": [
            {
                "type": "pdf",
                "authors": "Benabid F.", "year": "2017",
                "title": "Une plateforme Moodle dans une formation hybride diplômante : étude de l'évolution des usages",
                "journal": "RITPU", "vol": "14(2)", "pages": "24-38",
                "doi": "https://doi.org/10.18162/ritpu-2017-v14n2-02",
                "pdf": PDF_BENABID,
                "link_label": {"fr": "Lire l'article (PDF)", "ar": "قراءة المقال (PDF)"}
            },
            {
                "type": "url",
                "authors": "Loom Inc.", "year": "2024",
                "title": "Loom — Enregistrement vidéo d'écran pour l'éducation",
                "journal": "Loom", "vol": "", "pages": "", "doi": "",
                "url": "https://www.loom.com",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            },
        ]
    },

    "padlet": {
        "id": "padlet", "primary": True,
        "name": "Padlet",
        "logo": LOGO_PADLET,
        "color": "#B84A0A", "color_light": "#FEF1EA",
        "category": {"fr": "Tableau collaboratif / Brainstorming", "ar": "اللوحة التعاونية / العصف الذهني"},
        "website": "https://padlet.com",
        "summary": {
            "fr": (
                "Padlet est un tableau virtuel collaboratif en temps réel permettant de partager des idées, "
                "ressources, images et vidéos sur un mur numérique interactif. Utilisé pour le brainstorming, "
                "la collecte de travaux, les projets collaboratifs et l'animation participative. "
                "Bouaddi et al. (2025) montrent que les technologies utilisées en contexte éducatif "
                "améliorent les compétences en collaboration (β=0,20) et favorisent la résolution "
                "collective. Padlet incarne cette dimension grâce à son interface visuelle permettant "
                "à tous de contribuer simultanément sans compte obligatoire."
            ),
            "ar": (
                "Padlet لوحة تعاونية افتراضية فورية لمشاركة الأفكار والموارد والصور ومقاطع الفيديو. "
                "تُستخدم للعصف الذهني وجمع الأعمال والمشاريع التعاونية. "
                "تُبيّن دراسة بوعدي وآخرين (2025) أن التقنيات التعليمية تحسّن مهارات التعاون "
                "(β=0.20) وتدعم حل المشكلات الجماعي. يتيح Padlet لجميع المشاركين المساهمة "
                "آنياً من أجهزتهم دون حساب إلزامي."
            )
        },
        "advantages": {
            "fr": ["Collaboration en temps réel simultanée", "Interface visuelle intuitive", "Supporte texte, images, vidéos, liens, fichiers", "Partage via lien ou QR code", "Idéal pour brainstorming et projets", "Accessible sans compte pour les contributeurs"],
            "ar": ["تعاون فوري متزامن", "واجهة بصرية بديهية", "يدعم النصوص والصور والفيديو والروابط", "مشاركة عبر رابط أو رمز QR", "مثالي للعصف الذهني", "متاح دون حساب للمساهمين"]
        },
        "disadvantages": {
            "fr": ["Version gratuite limitée à 3 padlets", "Pas d'évaluation ni système de notes", "Peut devenir désorganisé avec nombreux contributeurs", "Confidentialité des données à surveiller"],
            "ar": ["النسخة المجانية محدودة بـ 3 لوحات", "لا تقييم ولا نظام درجات", "قد يصبح غير منظم مع كثير من المساهمين", "خصوصية البيانات تستوجب الانتباه"]
        },
        "stats": {"adoption": 45, "satisfaction": 4, "ease": 5, "interactivity": 4, "accessibility": 5},
        "references": [
            {
                "type": "pdf",
                "authors": "Bouaddi M. et al.", "year": "2025",
                "title": "Impact des outils numériques sur l'acquisition et l'amélioration des compétences transversales",
                "journal": "IRAFEM", "vol": "Vol.1 Issue 1", "pages": "1-24", "doi": "",
                "pdf": PDF_BEDDAA,
                "link_label": {"fr": "Lire l'étude (PDF)", "ar": "قراءة الدراسة (PDF)"}
            },
            {
                "type": "url",
                "authors": "Padlet Inc.", "year": "2024",
                "title": "Padlet — Tableau collaboratif pour l'éducation",
                "journal": "Padlet", "vol": "", "pages": "", "doi": "",
                "url": "https://padlet.com",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            },
        ]
    },

    # ════════════════════════════════════════════════════════════════
    # SECONDARY TOOLS — no dedicated PDF study → website link only
    # ════════════════════════════════════════════════════════════════

    "wooclap": {
        "id": "wooclap", "primary": False,
        "name": "Wooclap", "logo": LOGO_WOOCLAP,
        "color": "#3D2880", "color_light": "#EBE7F8",
        "website": "https://www.wooclap.com",
        "category": {"fr": "Évaluation formative / Interaction", "ar": "التقييم التكويني / التفاعل"},
        "summary": {
            "fr": "Wooclap est un outil interactif de quiz en temps réel qui augmente fortement la participation. Évalué 5/5, il permet QCM, questions ouvertes, sondages et nuages de mots depuis les smartphones.",
            "ar": "Wooclap أداة اختبارات فورية ترفع مشاركة الطلاب. حازت 5/5 وتتيح اختيار متعدد وأسئلة مفتوحة واستطلاعات من الهواتف."
        },
        "advantages": {"fr": ["Augmente la participation en cours", "Réponses anonymes possibles", "Compatible présentiel et distance", "Interface intuitive"], "ar": ["يرفع المشاركة", "إجابات مجهولة", "متوافق مع الحضور والبُعد", "واجهة بديهية"]},
        "disadvantages": {"fr": ["Fonctionnalités avancées payantes", "Nécessite Internet stable", "Dépendance aux smartphones"], "ar": ["ميزات متقدمة مدفوعة", "يتطلب إنترنت مستقر", "يعتمد الهواتف"]},
        "stats": {"adoption": 55, "satisfaction": 5, "ease": 5, "interactivity": 5, "accessibility": 4},
        "references": [
            {
                "type": "url",
                "authors": "Wooclap", "year": "2024",
                "title": "Wooclap — Outil d'interaction en temps réel pour l'enseignement",
                "journal": "Wooclap", "vol": "", "pages": "", "doi": "",
                "url": "https://www.wooclap.com",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            }
        ]
    },

    "moocs": {
        "id": "moocs", "primary": False,
        "name": "MOOCs", "logo": LOGO_MOOCS,
        "color": "#095043", "color_light": "#E4F2EF",
        "website": "https://www.coursera.org",
        "category": {"fr": "Formation ouverte / Apprentissage massif", "ar": "التعليم المفتوح الجماهيري"},
        "summary": {
            "fr": "Les MOOCs (Massive Open Online Courses) sont des cours en ligne ouverts. Bouaddi et al. (2025) prouvent leur impact sur la pensée critique (β=0,35) et la gestion du temps (β=0,45), mais le taux d'abandon reste élevé.",
            "ar": "MOOCs دورات إلكترونية مفتوحة ضخمة. أثبتت دراسة بوعدي (2025) تأثيرها على التفكير النقدي (β=0.35) وإدارة الوقت (β=0.45)، لكن نسبة التسرب مرتفعة."
        },
        "advantages": {"fr": ["Accès universel gratuit", "Impact sur la pensée critique (β=0,35)", "Apprentissage auto-rythmé", "Contenus de qualité"], "ar": ["وصول شامل مجاني", "تأثير على التفكير النقدي", "تعلم بوتيرة خاصة", "محتويات عالية الجودة"]},
        "disadvantages": {"fr": ["Taux d'abandon très élevé", "Manque d'interaction directe", "Leadership non impacté (β=0,05)"], "ar": ["نسبة تسرب مرتفعة جداً", "ضعف التفاعل المباشر", "القيادة غير متأثرة"]},
        "stats": {"adoption": 50, "satisfaction": 4, "ease": 4, "interactivity": 3, "accessibility": 5},
        "references": [
            {
                "type": "pdf",
                "authors": "Bouaddi M. et al.", "year": "2025",
                "title": "Impact des outils numériques sur l'acquisition et l'amélioration des compétences transversales",
                "journal": "IRAFEM", "vol": "Vol.1 Issue 1", "pages": "1-24", "doi": "",
                "pdf": PDF_BEDDAA,
                "link_label": {"fr": "Lire l'étude (PDF)", "ar": "قراءة الدراسة (PDF)"}
            },
            {
                "type": "url",
                "authors": "Coursera", "year": "2024",
                "title": "Coursera — Plateforme de MOOCs",
                "journal": "Coursera", "vol": "", "pages": "", "doi": "",
                "url": "https://www.coursera.org",
                "link_label": {"fr": "Visiter Coursera", "ar": "زيارة Coursera"}
            },
        ]
    },

    "canva": {
        "id": "canva", "primary": False,
        "name": "Canva", "logo": LOGO_CANVA,
        "color": "#006B70", "color_light": "#E4F3F4",
        "website": "https://www.canva.com/education",
        "category": {"fr": "Création de supports / Design", "ar": "إنشاء الدعائم / التصميم"},
        "summary": {
            "fr": "Canva est une plateforme de design graphique intuitive permettant de créer présentations, infographies et supports attractifs sans compétences techniques préalables.",
            "ar": "Canva منصة تصميم جرافيكي بديهية لإنشاء عروض وانفوغرافيات ودعائم جذابة دون مهارات تقنية."
        },
        "advantages": {"fr": ["Glisser-déposer intuitif", "Milliers de modèles prédéfinis", "Collaboration en temps réel", "Version gratuite généreuse pour l'éducation"], "ar": ["واجهة سحب وإفلات بديهية", "آلاف النماذج الجاهزة", "تعاون فوري", "نسخة مجانية سخية للتعليم"]},
        "disadvantages": {"fr": ["Fonctionnalités avancées payantes", "Dépendance à Internet", "Designs parfois similaires entre utilisateurs"], "ar": ["ميزات متقدمة مدفوعة", "اعتماد على الإنترنت", "تصاميم متشابهة أحياناً"]},
        "stats": {"adoption": 60, "satisfaction": 4, "ease": 5, "interactivity": 3, "accessibility": 5},
        "references": [
            {
                "type": "url",
                "authors": "Canva", "year": "2024",
                "title": "Canva for Education — Design graphique pour l'enseignement",
                "journal": "Canva", "vol": "", "pages": "", "doi": "",
                "url": "https://www.canva.com/education",
                "link_label": {"fr": "Visiter Canva Éducation", "ar": "زيارة Canva للتعليم"}
            }
        ]
    },

    "exam_net": {
        "id": "exam_net", "primary": False,
        "name": "Exam.net", "logo": LOGO_EXAMNET,
        "color": "#8B2020", "color_light": "#FAECEC",
        "website": "https://exam.net",
        "category": {"fr": "Évaluation sommative / Examens sécurisés", "ar": "الامتحانات الآمنة"},
        "summary": {
            "fr": "Exam.net est une plateforme d'examens sécurisés avec environnement verrouillé anti-fraude. Évaluée 4/5 pour sa sécurité élevée et la simplification de la gestion des copies.",
            "ar": "Exam.net منصة امتحانات آمنة ببيئة مقفلة مانعة للغش. حازت 4/5 لأمانها العالي وتبسيط إدارة الأوراق."
        },
        "advantages": {"fr": ["Environnement anti-fraude verrouillé", "Surveillance temps réel", "Dépôt centralisé des copies"], "ar": ["بيئة مقفلة مانعة للغش", "مراقبة فورية", "إيداع مركزي للأوراق"]},
        "disadvantages": {"fr": ["Coût de licence", "Dépendance à Internet", "Peut stresser les étudiants"], "ar": ["تكلفة الترخيص", "اعتماد على الإنترنت", "قد يضغط على الطلاب"]},
        "stats": {"adoption": 35, "satisfaction": 4, "ease": 4, "interactivity": 2, "accessibility": 4},
        "references": [
            {
                "type": "url",
                "authors": "Exam.net", "year": "2024",
                "title": "Exam.net — Plateforme d'examens sécurisés en ligne",
                "journal": "Exam.net", "vol": "", "pages": "", "doi": "",
                "url": "https://exam.net",
                "link_label": {"fr": "Visiter le site officiel", "ar": "زيارة الموقع الرسمي"}
            }
        ]
    },
}

PRIMARY_TOOLS   = [t for t in TOOLS_DATA.values() if t["primary"]]
SECONDARY_TOOLS = [t for t in TOOLS_DATA.values() if not t["primary"]]
ALL_TOOLS       = PRIMARY_TOOLS + SECONDARY_TOOLS
