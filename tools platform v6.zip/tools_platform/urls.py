from django.urls import path
from tools import views

urlpatterns = [
    path('', views.home, name='home'),
    path('tool/<str:tool_id>/', views.tool_detail, name='tool_detail'),
    path('compare/', views.compare, name='compare'),
    path('statistics/', views.statistics, name='statistics'),
    path('set-lang/<str:lang>/', views.set_language, name='set_language'),
]
